var searchData=
[
  ['read',['read',['../parser_8h.html#af816873151ddb0126e98bb2f914d8ed5',1,'parser.h']]]
];
