var searchData=
[
  ['bron_5fkerbosh',['bron_kerbosh',['../class_graph.html#a8277b59b0d4b5148870c5987b814eedc',1,'Graph']]]
];
