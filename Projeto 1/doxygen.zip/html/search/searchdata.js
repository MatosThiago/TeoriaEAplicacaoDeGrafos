var indexSectionsWithContent =
{
  0: "bcdghikmprs",
  1: "g",
  2: "gp",
  3: "bcdghmrs",
  4: "ik"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Macros"
};

