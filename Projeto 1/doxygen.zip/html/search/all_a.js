var searchData=
[
  ['show_5fcliques',['show_cliques',['../class_graph.html#a7c8e185530dd0a2e5f655f56698b3c8b',1,'Graph']]],
  ['show_5fvertices',['show_vertices',['../class_graph.html#a8c0664314701aa41aa3e863999c43f96',1,'Graph']]]
];
